package com.example.dchung.tarea_contactos;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText txtNombre;
    private EditText txtTelefono;
    private EditText txtEmail;
    private EditText txtDescripcion;
    private EditText txtFecha;

    Calendar mycalendar =  Calendar.getInstance();
    DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth) {
            mycalendar.set(Calendar.YEAR, year);
            mycalendar.set(Calendar.MONTH, monthOfYear);
            mycalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabels ();
        }
    };
    public void updateLabels() {
        String myFormat = "dd/MM/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat,Locale.ENGLISH);
        txtFecha.setText(sdf.format(mycalendar.getTime()));
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSiguiente=(Button)findViewById(R.id.btnSiguiente);
        txtNombre=(EditText) findViewById(R.id.txtNombre);
        txtTelefono=(EditText)findViewById(R.id.txtTelefono);
        txtEmail=(EditText)findViewById(R.id.txtEmail);
        txtDescripcion=(EditText)findViewById(R.id.txtDescripcion);
        txtFecha=(EditText)findViewById(R.id.txtFechaNac);

        txtFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(MainActivity.this, date, mycalendar
                        .get(Calendar.DAY_OF_MONTH), mycalendar.get(Calendar.MONTH),
                        mycalendar.get(Calendar.YEAR)).show();
            }
        });

        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strNombre;
                String strFechaNac="";
                String strTelefono="";
                String strEmail="";
                String strDescripcion="";

                strNombre=txtNombre.getText().toString();
                strFechaNac=txtFecha.getText().toString();
                strTelefono=txtTelefono.getText().toString();
                strEmail=txtEmail.getText().toString();
                strDescripcion=txtDescripcion.getText().toString();


                if (strNombre.length()==0 || strFechaNac.length()==0 || strTelefono.length()==0 || strEmail.length()==0 || strDescripcion.length()==0 )
                {
                    Snackbar.make(v,getResources().getString(R.string.Mensaje),Snackbar.LENGTH_SHORT).show();
                }
                else
                {
                    Intent intent1=new Intent(MainActivity.this,ConfirmacionRegistro.class);
                    intent1.putExtra(getResources().getString(R.string.pNombre),strNombre);
                    intent1.putExtra(getResources().getString(R.string.pFechaNac),strFechaNac);
                    intent1.putExtra(getResources().getString(R.string.pTelefono),strTelefono);
                    intent1.putExtra(getResources().getString(R.string.pEmail),strEmail);
                    intent1.putExtra(getResources().getString(R.string.pDescrip),strDescripcion);
                    startActivity(intent1);
                }

            }
        });


        Intent intent = getIntent();
        if (null != intent) { //Null Checking

            txtNombre.setText(intent.getStringExtra(getResources().getString(R.string.pNombre)));
            txtTelefono.setText(intent.getStringExtra(getResources().getString(R.string.pTelefono)));
            txtEmail.setText(intent.getStringExtra(getResources().getString(R.string.pEmail)));
            txtDescripcion.setText(intent.getStringExtra(getResources().getString(R.string.pDescrip)));
            txtFecha.setText(intent.getStringExtra(getResources().getString(R.string.pFechaNac)));

        }

    }
}

